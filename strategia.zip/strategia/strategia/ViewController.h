//
//  ViewController.h
//  strategia
//
//  Created by Imac5 on 26/10/15.
//  Copyright (c) 2015 Imac1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NumericInputValidator.h"
#import "AlphaInputValidator.h"
#import "CustomTextField.h"
@interface ViewController : UIViewController <UITextFieldDelegate>
{
@private
CustomTextField *numericTextField_;
CustomTextField *alphaTextField_;
}
@property (nonatomic, retain) IBOutlet CustomTextField *numericTextField;
@property (nonatomic, retain) IBOutlet CustomTextField *alphaTextField;
@end
