//
//  InputValidator.m
//  strategia
//
//  Created by Imac5 on 26/10/15.
//  Copyright (c) 2015 Imac1. All rights reserved.
//

#import "InputValidator.h"

@implementation InputValidator
-(BOOL) validateInput:(UITextField *) input error:(NSError **) error {
    if(error){
        *error=nil;
        
    }return NO;
    
}
@end
