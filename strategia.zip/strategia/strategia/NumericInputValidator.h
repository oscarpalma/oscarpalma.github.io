//
//  NumericInputValidator.h
//  strategia
//
//  Created by Imac5 on 26/10/15.
//  Copyright (c) 2015 Imac1. All rights reserved.
//

#import "InputValidator.h"

@interface NumericInputValidator : InputValidator
{}
-(BOOL) validateInput:(UITextField *)input error:(NSError **)error;

@end
