#import "InputValidator.h"
@interface CustomTextField : UITextField
{
@private
InputValidator *inputValidator_;
}
@property (nonatomic, retain) IBOutlet InputValidator *inputValidator;
- (BOOL) validate;
@end

