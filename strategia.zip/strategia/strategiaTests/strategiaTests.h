//
//  strategiaTests.h
//  strategiaTests
//
//  Created by Imac5 on 26/10/15.
//  Copyright (c) 2015 Imac1. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface strategiaTests : SenTestCase

@end
