//
//  strategiaTests.m
//  strategiaTests
//
//  Created by Imac5 on 26/10/15.
//  Copyright (c) 2015 Imac1. All rights reserved.
//

#import "strategiaTests.h"

@implementation strategiaTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in strategiaTests");
}

@end
